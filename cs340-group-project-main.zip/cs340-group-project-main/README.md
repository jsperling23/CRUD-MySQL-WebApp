Source Code Originality Citations:
1) templates/customer_edit.js: 
Date: 02/29/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/edit_people.j2 as a template for our location_edit.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/edit_people.j2

2) templates/customers.j2:
Date: 03/03/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/people.j2 as a template for our products.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/people.j2

3) templates/location_edit.j2:
Date: 02/29/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/edit_people.j2 as a template for our location_edit.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/edit_people.j2 

4) templates/locations.j2
Date: 02/29/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/people.j2 as a template for our locations.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/people.j2

5) templates/product_edit.j2
Date: 02/29/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/edit_people.j2 as a template for our product_edit.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/edit_people.j2

6) templates/products.j2
Date: 03/03/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/people.j2 as a template for our products.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/people.j2

7) templates/productSale_edit.j2
Date: 02/29/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/edit_people.j2 as a template for our product_edit.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/edit_people.j2

8) templates/productsSales.j2
Date: 03/03/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/people.j2 as a template for our productSales.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/people.j2

9) templates/sales_edit.j2
Date: 02/29/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/edit_people.j2 as a template for our product_edit.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/edit_people.j2

10) templates/sales.j2
Date: 03/03/2024
Based on osu-cs340-ecampus/flask-starter-app/templates
Used the bsg_people_app/templates/people.j2 as a template for our products.j2
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/templates/people.j2

11) app.py
Date: 02/29/2024
Based on osu-cs340-ecampus/flask-starter-app/bsg_people_app
Used the bsg_people_app/app.py as a template for our app.py
Source URL: https://github.com/osu-cs340-ecampus/flask-starter-app/blob/master/bsg_people_app/app.py



Running the project locally:

pip3 install --user virtualenv

python3 -m venv .

source ./bin/activate

pip3 install flask-mysqldb
